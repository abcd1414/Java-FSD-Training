package com.example.SpringBootClinic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootClinic.entity.Patient;
import com.example.SpringBootClinic.service.PatientService;

@RestController
@RequestMapping("/patient")
public class PatientController {
	
	@Autowired
	private PatientService patientService;
	
	@PostMapping("/save")
	public Patient savePatient(@RequestBody Patient patient)
	{
		return patientService.savePatient(patient);
	}
	
	@GetMapping("/list")
	public List<Patient> getPatients(@RequestBody Patient patient)
	{
		return patientService.getPatients();
	}
	
	@PutMapping("/update/{patient_id}")
	public Patient updatePatient(@RequestBody Patient patient, @PathVariable("patient_id") Long id)
	{
		return patientService.updatePatient(id, patient);
	}
	
	@PutMapping("/delete/{patient_id}")
	public String deletePatient(@PathVariable("patient_id") Long id)
	{
		 patientService.deletePatient(id);
		 return "deleted successfully";
	}
	
}
